import sys
import boto3
import json
import logging
#import rds_config
import pymysql

#rds settings
rds_host  = "aws-mock-db.cluster-csaruqlxxway.us-east-1.rds.amazonaws.com"
name = 'admin'
password = 'Password'
db_name = 'krackit11'
client = boto3.client('cognito-idp')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=100)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")
def lambda_handler(event, context):
    """
    This function fetches content from MySQL RDS instance
    """
    token = event['headers']['access_token']
    contest_id = event['body']['contest_id']
    match_id = event['body']['match_id']
    user_team_id = event['body']['user_team_id']
    response = client.get_user(
        AccessToken = token
        )  
    uname = response['Username']
    list1 = [] 
    list2 = []
    list3 = []
    with conn.cursor() as cur:
        cur.execute("select count(leaderboard_id)  from leaderboard where user_id= %s and contest_id = %s and match_id = %s and user_team_id = %s",(uname,contest_id,match_id,user_team_id))
        for row in cur:
            list3.append(row)
        entry_in_leaderboard = list3[0][0]
        if entry_in_leaderboard == 0:
            cur.execute("select count(user_team_id) from user_team where user_id= %s AND contest_id= %s AND match_id= %s ",(uname,contest_id,match_id))
            select_query_results = []
            for row in cur:
                select_query_results.append(row)
            num_of_teams = select_query_results[0][0]
            cur.execute("select balance from users where user_id='"+uname+"'")
            for row in cur:
                list1.append(row)
            
            cur.execute("select entry_fee from contest where contest_id=%s",(contest_id,))
            for row in cur:
                list2.append(row)
            contest_fee = list2[0][0]
            balance = list1[0][0]
            if num_of_teams == 0:
                result = "Create Team To Enter The Contest"
            elif balance<contest_fee:
                result = "Balance is insufficient to join the contest"
            else:
                cur.execute("SET @contestfee = (select entry_fee from contest where contest_id=%s)",(contest_id,))
                cur.execute("update users set balance = balance - @contestfee where user_id='"+uname+"'")
                cur.execute("Update users set deposit_amt = deposit_amt + @contestfee")
                cur.execute("update company_account set input_amt = input_amt + @contestfee where contest_id=%s",(contest_id,))
                cur.execute("UPDATE company_account SET commission = input_amt * 0.2 where contest_id= %s ",(contest_id,))
                cur.execute("UPDATE company_account SET distribution = input_amt - commission where contest_id=%s",(contest_id,))
                cur.execute("Insert into leaderboard (user_id,contest_id,points,match_id,user_team_id) values(%s,%s,%s,%s,%s)",(uname,contest_id,0,match_id,user_team_id))
                result = "Joined Contest"
        else:
            result = "Already joined"
        # cur.execute("select * from user_team")
        # for row in cur:
        #     print(row)
    conn.commit()

    return result