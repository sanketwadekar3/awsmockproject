import sys
import boto3
import json
#import jsonify
import logging
#import rds_config
import pymysql
#rds settings
rds_host  = "aws-mock-db.cluster-csaruqlxxway.us-east-1.rds.amazonaws.com"
name = 'admin'
password = 'Password'
db_name = 'krackit11'

logger = logging.getLogger()
logger.setLevel(logging.INFO)
try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=100)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")
def lambda_handler(event, context):
    item_count = 0

    with conn.cursor() as cur:
        query_results = []
        cur.execute("select t.team_name,m.match_id,m.dates from team t,matches m where team_id in(select mteam_id from match_team where match_id in(select match_id from matches))")
        for row in cur:
            item_count += 1
            logger.info(row)
            #jsonify(row)
            query_results.append(row)
            #print(row)
    date = json.dumps(query_results[0][2], default=str)
    result = {
        "Team 1" : query_results[0][0],
        "Team 2" : query_results[1][0],
        "Match ID" : query_results[0][1],
        "Date" : date
        }
    conn.commit()
    return result