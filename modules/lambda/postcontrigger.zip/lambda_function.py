import sys
import boto3
import json
import logging
import urllib.request
#import rds_config
import pymysql

rds_host  = "aws-mock-db.cluster-csaruqlxxway.us-east-1.rds.amazonaws.com"
name = 'admin'
password = 'Password'
db_name = 'krackit11'

logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    print("connecting")
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=100)
    c="ok"
except pymysql.MySQLError as e:
    c="error"
    print("errorrrrrrrrr")
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()



def lambda_handler(event, context):
    email = event['request']['userAttributes']['email']
    name = event['request']['userAttributes']['name']
    phone_number = event['request']['userAttributes']['phone_number']
    birthdate = event['request']['userAttributes']['birthdate']
    table_name = 'users'
    print(email, name, phone_number, birthdate)
    with conn.cursor() as cur:

        cur.execute("insert into users (user_id,email,dob,mob,balance,deposit_amt,winning_amt,bonus) values('"+name+"','"+email+"','"+birthdate+"','"+phone_number+"',"+"100,0,0,100);")
        
    conn.commit()

    return event