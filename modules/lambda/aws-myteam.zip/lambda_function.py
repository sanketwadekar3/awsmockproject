import sys
import boto3
import json
#import jsonify
import logging
#import rds_config
import pymysql

#rds settings
rds_host  = "aws-mock-db.cluster-csaruqlxxway.us-east-1.rds.amazonaws.com"
name = 'admin'
password = 'Password'
db_name = 'krackit11'
client = boto3.client('cognito-idp')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=100)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")
def lambda_handler(event, context):
    token = event['headers']['access_token']
    response = client.get_user(AccessToken = token)
    user_id = response['Username']
    match_id = event['body']['match_id']
    with conn.cursor() as cur:
        pids_query_results = []
        cur.execute("select concat(pid1,',',pid2,',',pid3,',',pid4,',',pid5,',',pid6,',',pid7,',',pid8,',',pid9,',',pid10,',',pid11) as pids from user_team where user_id=%s AND match_id=%s",(user_id,match_id))
        for row in cur:
            pids_query_results.append(row)
            
        pids_list = []
        for row in pids_query_results:
            pids_list.append(list(map(int,row[0].split(','))))
        
        cur.execute("select * from player where player_id in {}".format(tuple(pids_list[0])))
        query_results = []
        for row in cur:
            query_results.append(row)

    conn.commit()  
    result = []
    
    for i in range(0,11):
        details={"Player-"+str((i+1)) : {
          "Name" : query_results[i][1],
          "Team" : query_results[i][2],
          "Category" : query_results[i][3],
          "credits" : query_results[i][4]}
          }
        result.append(details)
    
    return {"Team":result}
    