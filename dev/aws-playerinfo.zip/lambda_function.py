import sys
import boto3
import json
import logging
#import rds_config
import pymysql
#rds settings
rds_host  = "aws-mock-db.cluster-csaruqlxxway.us-east-1.rds.amazonaws.com"
name = 'admin'
password = 'Password'
db_name = 'krackit11'
client = boto3.client('cognito-idp')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=100)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")
def lambda_handler(event, context):
    token = event['headers']['access_token']
    response = client.get_user( AccessToken = token )
    query_results = [] 
    
    uname = response['Username']
    with conn.cursor() as cur:
        sql= "select user_id,email,dob,mob from users where user_id='"+uname+"'"
        cur.execute(sql)
        for row in cur:
            logger.info(row)
            query_results.append(row)
    #var = json.dumps(list1)
    conn.commit()
    result = {
        "Name" : query_results[0][0],
        "Email" : query_results[0][1],
        "DoB" : query_results[0][2],
        "Mobile Number" : query_results[0][3]
    }
    return result
   