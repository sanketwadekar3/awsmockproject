import sys
import boto3
import json
import logging
#import rds_config
import pymysql

#rds settings
rds_host  = "aws-mock-db.cluster-csaruqlxxway.us-east-1.rds.amazonaws.com"
name = 'admin'
password = 'Password'
db_name = 'krackit11'

logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=100)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")

def lambda_handler(event, context):
    """
    This function fetches content from MySQL RDS instance
    """
    client = boto3.client('cognito-idp')
    token = event['headers']['access_token']
    response = client.get_user(AccessToken = token)
    user_id = response['Username']
    team_name = event['body']['team_name']
    match_id = event['body']['match_id']
    contest_id = event['body']['contest_id']
    player_id_list = event['body']['player_id_list']
    query_results = [] 
    with conn.cursor() as cursor:
        cursor.execute("select count(user_team_id) from user_team where user_id= %s AND contest_id= %s AND match_id= %s ",(user_id,contest_id,match_id))
        select_query_results = []
        for row in cursor:
            select_query_results.append(row)
        num_of_teams = select_query_results[0][0]
        print(num_of_teams)
    # with conn.cursor() as cur:
        if num_of_teams == 0:
            cursor.execute("insert into user_team (user_team_name,user_id,match_id,contest_id,pid1,pid2,pid3,pid4,pid5,pid6,pid7,pid8,pid9,pid10,pid11) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(team_name,user_id,match_id,contest_id,player_id_list[0]['pid1'],player_id_list[0]["pid2"],player_id_list[0]["pid3"],player_id_list[0]["pid4"],player_id_list[0]["pid5"],player_id_list[0]["pid6"],player_id_list[0]["pid7"],player_id_list[0]["pid8"],player_id_list[0]["pid9"],player_id_list[0]["pid10"],player_id_list[0]["pid11"]))
            result = "success" 
        else:
            result = "you already have a team for this match"
            
    conn.commit()
    return result

