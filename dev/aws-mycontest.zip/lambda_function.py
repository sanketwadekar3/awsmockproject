import sys
import boto3
import json
#import jsonify
import logging
#import rds_config
import pymysql


#rds settings
rds_host  = "aws-mock-db.cluster-csaruqlxxway.us-east-1.rds.amazonaws.com"
name = 'admin'
password = 'Password'
db_name = 'krackit11'

logger = logging.getLogger()
logger.setLevel(logging.INFO)
client = boto3.client('cognito-idp')


try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=100)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")
def lambda_handler(event, context):
    """
    This function fetches content from MySQL RDS instance
    """
    token = event['headers']['access_token']
    response = client.get_user( AccessToken = token )
    user_id = response['Username']
    match_id = event['body']['match_id']
    with conn.cursor() as cur:
        contest_id_list = []
        cur.execute("select contest_id from leaderboard where user_id = %s and match_id = %s ",(user_id,match_id))
        for row in cur:
            contest_id_list.append(row[0])
        query_results = []
        cur.execute("select * from contest where contest_id in {}".format(tuple(contest_id_list)))
        for row in cur:
            query_results.append(row)
    conn.commit()
    result = []
    for contest in query_results:
        details = {
            "contest_id" : contest[0],
            "contest_name" : contest[1],
            "prize_amt " : contest[2],
            "entry_fee " : contest[3],
            "max_count " : contest[4],
            "real_count " : contest[5]
        }
        result.append(details)
    return {"contest_list" : result}