import sys
import boto3
import json
#import jsonify
import logging
#import rds_config
import pymysql


#rds settings
rds_host  = "aws-mock-db.cluster-csaruqlxxway.us-east-1.rds.amazonaws.com"
name = 'admin'
password = 'Password'
db_name = 'krackit11'

logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=100)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")
def lambda_handler(event, context):
    """
    This function fetches content from MySQL RDS instance
    """
    match_id = event['body']['match_id']
    with conn.cursor() as cur:
        query_results = []
        cur.execute("select * from contest where match_id= %s and contest_type = 'public' ",(match_id,))
        for row in cur:
            logger.info(row)
            query_results.append(row)
    conn.commit()
    result = []
    for contest in query_results:
        details = {
            "contest_id" : contest[0],
            "contest_name" : contest[1],
            "prize_amt " : contest[2],
            "entry_fee " : contest[3],
            "max_count " : contest[4],
            "real_count " : contest[5]
        }
        result.append(details)
    return {"contest_list" : result}