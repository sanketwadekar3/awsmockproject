import sys
import boto3
import json
import logging
#import rds_config
import pymysql
#rds settings
rds_host  = "aws-mock-db.cluster-csaruqlxxway.us-east-1.rds.amazonaws.com"
name = 'admin'
password = 'Password'
db_name = 'krackit11'
client = boto3.client('cognito-idp')
logger = logging.getLogger()
logger.setLevel(logging.INFO)
c="k"

try:
    print("connecting")
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=100)
    c="ok"
except pymysql.MySQLError as e:
    c="error"
    print("errorrrrrrrrr")
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")
def lambda_handler(event, context):
    """
    This function fetches content from MySQL RDS instance
    """

    item_count = 0
    token = event['headers']['access_token']
    response = client.get_user(
        AccessToken = token
        )
    contest_id = event['body']['contest_id']
    list1 = [] 
    with conn.cursor() as cur:
        cur.execute("select p.player_name,c.category_name,p.credit,t.team_name from player p,team t,category c where p.team_id in(select mteam_id from match_team where match_id in(select match_id from contest where contest_id='"+contest_id+"')) AND p.team_id=t.team_id AND p.category_id=c.category_id")
        for row in cur:
            item_count += 1
            logger.info(row)
            list1.append(row)
            y = json.dumps(list1)
            print(row)
    conn.commit()

    return y
