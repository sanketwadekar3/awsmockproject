import sys
import boto3
import json
import logging
#import rds_config
import pymysql

#rds settings
client = boto3.client('cognito-idp')
rds_host  = "aws-mock-db.cluster-csaruqlxxway.us-east-1.rds.amazonaws.com"
name = 'admin'
password = 'Password'
db_name = 'krackit11'

logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=100)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")
def lambda_handler(event, context):
    """
    This function fetches content from MySQL RDS instance
    """

    item_count = 0
    token = event['headers']['access_token']
    amount = event['body']['amount']
    response = client.get_user(AccessToken = token)
    user_id = response['Username']
    query_results = []
    with conn.cursor() as cur:
        cur.execute("update users set balance= balance + '"+amount+"' where user_id='"+user_id+"'")
        cur.execute("select balance from users where user_id='"+user_id+"'")
        for row in cur:
            item_count += 1
            logger.info(row)
            query_results.append(row)
    conn.commit()
    result = {
        "Updated Balance" : query_results[0][0]
    }
    return result

